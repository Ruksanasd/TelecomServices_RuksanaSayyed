/**
 * 
 */
/**
 * 
 */
module OJDBC {
	requires java.sql;
}