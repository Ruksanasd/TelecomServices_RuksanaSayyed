package jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

public class Calculator {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		//step2
		Connection con=DriverManager.getConnection("jdbc:orace:thin:@localhost:1521:xe","system","ruksana");
		CallableStatement cst=con.prepareCall("{CALL square123(?,?,?)}");
		System.out.println("Enter a number");
		Scanner sc=new Scanner(System.in);
	
	}

}
