package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class jdbcApp1 {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		//step1
		Class.forName("oracle.jdbc.driver.OracleDriver");
		//step2
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","ruksana");
	    System.out.println("Connection Successfull");
	    
	    //creating table
	    Statement st=conn.createStatement();
	    //st.executeUpdate("create table Employee(Eid number primary key, Designation varchar(20), Salary number)");
	    //System.out.println("table created successfully");
	    
	    //updating table
	    //st.executeUpdate("insert into Employee values(101,'Q/A',20000)");
	    //st.executeUpdate("insert into Employee values(102,'Development',50000)");
	    //st.executeUpdate("update Employee set Designation='Org' where Eid=102");
	    //st.executeUpdate("delete from Employee where Eid=102");
	    //st.executeUpdate("insert into Employee values(201,'frontend',20000)");
	    //st.executeUpdate("insert into Employee values(102,'backend',50000)");
	    //System.out.println(" done");
	    
	    //selecting
	    //set.executeQuery("select*from Employee where Eid<=3");
	    System.out.println(" done");
	    
	      
	}
}
