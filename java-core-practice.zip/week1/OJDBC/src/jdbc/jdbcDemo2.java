package jdbc;

public class jdbcDemo2 {

}
