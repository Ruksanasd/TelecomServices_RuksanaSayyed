package com.testingJunit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CalculatorTest {

	@Test
	void testSum() {
		fail("Not yet implemented");
	}

	@Test
	void testDifference() {
		fail("Not yet implemented");
	}

	@Test
	void testProduct() {
		fail("Not yet implemented");
	}

	@Test
	void testDiv() {
		Calculator c=new Calculator();
		assertEquals()
		//fail("Not yet implemented");
	}

}
