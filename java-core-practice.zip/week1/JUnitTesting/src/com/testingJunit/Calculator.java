package com.testingJunit;

public class Calculator 
{
	int sum(int a,int b) 
	{
		return (a+b);
	}
	int difference(int a,int b)
	{
		return (a-b);
	}
	int product(int a,int b)
	{
		return (a*b);
	}
	int div(int a,int b)
	{
		return (a/b);
	}
}
