package com.testingJunit;

public class Loan {
	int getEmi(int amt)
	{
		return (amt/12);
	}

}
