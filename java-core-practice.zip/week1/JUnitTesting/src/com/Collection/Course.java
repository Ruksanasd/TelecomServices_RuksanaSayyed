package com.Collection;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class Course 
{
	Integer id;
	String name;
	Double fee;
	
	public Course(Integer id, String name, Double fee) 
	{
		super();
		this.id = id;
		this.name = name;
		this.fee = fee;
	}
	
	@Override
	public String toString() 
	{
		return "Course [id=" + id + ", name=" + name + ", fee=" + fee + "]";
	}
}
interface CourseService
{
	String addCourse(Course c);
	List<Course> listcourses();
	String updateCourse(Integer cid);
	String deleteCourse(Integer cid);
	List<Course> listCourses();
}
 class CourseServiceImpl implements CourseService
{
	List<Course> courseList=new ArrayList<>();

	@Override
	public String addCourse(Course c) 
	{
		courseList.add(c);
		return "ok";
	}

	@Override
	public String updateCourse(Integer cId) 
	{
	
		return "ok";
	}

	@Override
	public String deleteCourse(Integer cId) 
	{
		
		return "ok";
	}

	@Override
	public List<Course> listcourses() 
	{
		
		return courseList;
	}

	@Override
	public List<Course> listCourses() {
		// TODO Auto-generated method stub
		return null;
	}
}

