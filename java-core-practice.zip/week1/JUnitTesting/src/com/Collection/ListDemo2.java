package com.Collection;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class ListDemo2 {

	public static void main(String[] args) {
		Set<String> names=new LinkedHashSet<>();
		names.add("Ruksana");
		names.add("Sayyed");
		System.out.println();
		Set<Object> l=new TreeSet<>();
		l.add(23);
		l.add(86);
		System.out.println(l);
		Iterator i=l.iterator();
		while(i.hasNext())
			System.out.println(i.next());
		System.out.println("lambda");
		l.forEach(x->System.out.println(x));

	}

}
