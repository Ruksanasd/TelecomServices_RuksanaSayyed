package com.Collection;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ListDemo {

	public static void main(String[] args) {
		List l=new ArrayList();
		l.add(23);
		l.add(313,144);
		l.add("arrayList");
		l.add(LocalDate.now());
		System.out.println(l);
		System.out.println(l.size());
		
	
		
	}

}
