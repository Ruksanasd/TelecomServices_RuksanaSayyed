package com.Collection;

import static org.junit.jupiter.api.Assertions.assertLinesMatch;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MapDemo {

	public static void main(String[] args) {
		Map<Integer,String> map=new HashMap<>();
		map.put(1, "ruksana");
		map.put(3, "sayyed");
		map.put(2, "riddhu");
		map.put(4, null);
		map.put(3, "hadiya");
		map.put(2, "farana");
		System.out.println(map);
		Set keys=map.keySet();
		System.out.println(keys);
		Collection vals=map.values();
		System.out.println();
		Set kv=hm.entrySet();
		Iterator i=kv.iterator();
		while(i.hasNext())
		{
			Map.Entry entry.
			}
		}

}
