package ExceptionDemo;

public class DepositException extends Exception {
	
	DepositException(String msg)
	{
		super(msg);
	}

}
