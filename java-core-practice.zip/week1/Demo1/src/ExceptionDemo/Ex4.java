package ExceptionDemo;

public class Ex4 {

	public static void main(String[] args) {
		try(FileReader f=new FileReader("c:\\abc.txt");){
		}
		catch
	}

}
