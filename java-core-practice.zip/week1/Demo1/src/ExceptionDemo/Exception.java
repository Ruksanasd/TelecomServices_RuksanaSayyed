package ExceptionDemo;

public class Exception {

	public static void main(String[] args) {
		int a=10;
		int b=25;
		int p[]= {3,8,5};
		//thread.sleep(500);
		try {
			int c=a/b;
		    System.out.println(p[4]);
		    System.out.println("Result is:"+c);
		}
		}

}
