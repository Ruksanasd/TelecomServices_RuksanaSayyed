package ExceptionDemo;

public class Ex3 {

	public static void main(String[] args) {
		FileReader f=null;
		try {
			f=new FileReader
		}

	}

}
