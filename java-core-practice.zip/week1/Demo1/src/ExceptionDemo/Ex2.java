package ExceptionDemo;

public class Ex2 {

	public static void main(String[] args) {
		int a=10;
		int b=0;
		int p[]={3,8,5};
		try {
			try {
				int c=a/b;
				System.out.println(c);
			}
			catch(ArithmeticException e) {
				System.out.println(e);
			}
			System.out.println(p[4]);
			
		}
		catch(ArrayIndexOutOfBoundsException g)
		{
			System.out.println(g);
		}
		}

}
