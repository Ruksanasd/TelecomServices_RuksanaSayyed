package com.tms.abstraction;

public class housingloan extends Loan {
	void applyLoan(String name,double amount) {
		System.out.println(name+" loan of amount Rs"+amount+"applied");
	}
	void submitDocs() {
		System.out.println("docs are submited");
	}
		int getEmi(){
		 return 0;
	}
}
