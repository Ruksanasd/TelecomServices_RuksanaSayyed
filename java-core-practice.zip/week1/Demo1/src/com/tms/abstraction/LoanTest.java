package com.tms.abstraction;

public class LoanTest {
	public static void main(String[] args) {
		//Loan l;
		//housingloan hl=new housingloan();
	    //l=hl;
		Loan l=new housingloan();
		l.applyLoan("ruksana", 200000.00);
		l.submitDocs();
		System.out.println(l.getEmi());
		l=new vehicleloan();
		l.applyLoan("virat", 110000.00);
		l.submitDocs();
		System.out.println(l.getEmi());
	}
}
