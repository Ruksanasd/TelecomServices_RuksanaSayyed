package com.tms.interfaces;

public interface surity {
	void sdocs();
	

}
