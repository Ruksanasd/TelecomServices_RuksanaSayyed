package com.tms.interfaces;

public class Housing implements InterfaceLoan,surity {
	public void applyInterfaceLoan(String name,double amt) {
		System.out.println(name+"loan amount of Rs"+amount+"applied");
	}
	void submitDocs() {
		System.out.println("docs are submited");
	}
		int getEmi(){
		 return 0;
	}
}

