package com.tms.interfaces;

public interface Parking {
	void getslot();

}
