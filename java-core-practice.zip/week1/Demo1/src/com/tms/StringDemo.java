package com.tms;
import java.util.Scanner;
public class StringDemo {

	public static void main(String[] args) {
		String name="Verizon Developer";
		String name1=new String("Java Developer");
		System.out.println(name.length());
		System.out.println(name.toLowerCase());
		System.out.println(name.concat("hyd"));
		System.out.println(name.charAt(3));
		//name.replace('e','f');
		System.out.println(name.indexOf("e"));
		System.out.println(name1.lastIndexOf("e"));
		System.out.println(name.compareTo(name1));
		System.out.println(name.equals(name1));
		System.out.println(name==name1);
		
		/*Scanner sc=new Scanner(System.in);
		String token[]=comments.split(" ");
		for(int i=0;i<token.length;i++)
			System.out.println(tokens[i]);*/
		
		
		System.out.println();
		
	}

}
