package com.tms.java;
import java.util.Random;
import java.util.function.Supplier;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class PreDefinedFI {

	public static void main(String[] args) {
		Consumer<Integer>con1=(a)->System.out.println("square of given num"+a*a);
		con1.accept(3);
		
		Supplier<Integer>s1=( )->new Random().nextInt(1000);
		System.out.println(s1.get());
		
		Predicate<Double>p=(a)->a%2==0;
		System.out.println(p.test(3.77));
		System.out.println(p.test(44.8));
		
		Function<String,Integer>f=(name)->Integer.parseInt(name);
		System.out.println(f.apply("34")+3);
		
		
		

	}

}
