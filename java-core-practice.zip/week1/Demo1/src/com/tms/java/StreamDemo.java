package com.tms.java;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class StreamDemo {

	public static void main(String[] args) {
		
		List<Integer> list=Arrays.asList(5,3,6,32,56,11,74,2,45,12,654,45);
		list.forEach(x->System.out.println(x+" "));
		//sort,filter even,square
		System.out.println();
		list.stream().sorted().filter(x->x<=5).limit(8).forEach(x->System.out.println(x+" "));
		System.out.println();
		Optional<Integer> max=list.stream().sorted(Collections.reserveOrder()).skip(1).findFirst();
		
		if(max.isPresent())
			System.out.println("Max:"+max.get());
		String s=null;
		System.out.println(s.length());
		Optional<String>s1=Optional.ofNullable(null);
		if(s1.isPresent())
			System.out.println(s1.get());
		else
			System.out.println("Empty");
		List<Integer> newList=>Arrays.asList(12,2,5,21,54);
		List<Integer> List2=newList.stram().sorted(Collections.reserveOrder()).collect(Collectors.tolist());
		
		list2.forEach(x->sysout)
		
	}

}
