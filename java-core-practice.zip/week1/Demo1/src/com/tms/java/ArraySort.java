package com.tms.java;

import java.util.Arrays;

public class ArraySort {

	public static void main(String[] args) {
		int a[]= {4,9,32,77,21};
		for(int x:a)
		{
			System.out.println(x);
		}
		Arrays.sort(a);
		for(int x:a)
		   System.out.println(x);
		
	
	    int b[]=new int[5];
	    Arrays.fill(b,43);
	    for(int x:b) 
	    {
	    	System.out.println(x);
	    }
	    
	   
		   
}
}