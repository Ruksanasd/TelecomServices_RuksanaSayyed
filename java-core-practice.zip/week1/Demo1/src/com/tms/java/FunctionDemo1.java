package com.tms.java;
//@FuntionalInterface
interface Arith<T>{
	T op( T a,T b);
}

public class FunctionDemo1
{
	public static void main(String[] args) {
		Arith<Integer> ar0=(a,b)->a*a+b*b;
		System.out.println(ar0.op(29, 7));
		
		Arith<Double> ar1=(a,b)->a+b;
		System.out.println(ar1.op(5.9, 9.3));
		
		Arith<Integer> ar2=(a,b)->a*b;
		System.out.println(ar2.op(7, 9));
	}

}
