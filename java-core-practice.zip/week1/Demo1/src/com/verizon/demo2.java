package com.verizon;

import java.util.Scanner;

public class demo2 {
	//account account;
	
	public static void main(String[] args)
		Account a=new Account();
		System.out.println(a.);
		/*Scanner sc=new Scanner(System.in);
		System.out.println("Enter length, breadth of rect");
		int l=sc.nextInt();
		int b=sc.nextInt();
		if(l>0 && b>0) 
		{
		int area=l*b;
		System.out.println("Area is:"+area);
		}
		else
			System.out.println("Enter valid inputs");*/
	}
}
