package com.verizon;

public class employee extends person{
	String desg;
	employee()
	{
		System.out.println("in child....");
	}
	
	public employee(String desg) {
		//super(10,"ruksana");
		this();
		this.desg= desg;
		System.out.println(this.desg);
	}
	
	public static void main(String[] args) {
		employee el=new employee("FSD");
		
		}

}
