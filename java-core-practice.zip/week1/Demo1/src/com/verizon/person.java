package com.verizon;

public class person {
	int id;
	String name;
	person(){
		System.out.println("in parent...");
	}

	person(int id, String name) {
		this.id=id;
		this.name=name;
		System.out.println("in parameterised constructor:"+id+" "+name);
		

	}

}
