package com.verizon;

public class Account {
	int accNumber;
	String name;
	double balance;
	Account()
	{
		accNumber=999;
		name="Ruksana";
		balance=10000.00;
	}
	Account(int accnumber,String name,double balance)
	{
		this.accNumber=accNumber;
		this.name=name;
		this.balance=balance;
	}
		void deposit(double amt)
		{
			balance+=amt;
		}
		void withdraw(double amt)
		{
			balance-=amt;
		}
		double getbalance()
		{
			return balance;
		}
}