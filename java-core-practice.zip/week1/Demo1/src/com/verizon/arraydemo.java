package com.verizon;

public class arraydemo {

	public static void main(String[] args)
	{
		int a[]= {2,34,22,56,95,11,9,47};
		int sum=0;
		for(int i=0; i<a.length;i++) {
			//System.out.println(a[i]);
			sum+=a[i];
		}
		System.out.println("sum:"+sum);
		int b[]=new int[5];
		System.arraycopy(a, 0, b, 2,3);
		for(int i=0;i<b.length;i++)
			System.out.println(b[i]+" ");
	}

}
