package com.verizon.poly;

public class MRide1 {

}
