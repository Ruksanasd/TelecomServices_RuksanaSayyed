package com.verizon.poly;

public class MRide extends Ride{
    @Override
    void sq(int s) {
    	System.out.println("perimeter:"+(4*s));
    }
    public static void main(String[] args) {
    	Ride m=new MRide();
    	m.sq(4);
    	
    	m=new Ride();
    	m.sq(4);
    }
}
