package com.verizon.poly;

public class Mload {
	
	void area(int s) 
	{
		System.out.println("Square:"+(s*s));
	}
	void area(int l, int b) 
	{
		System.out.println("rectangle:"+(l*b));
	}
	void area(double r) 
	{
		System.out.println("circle:"+(3.14*r*r));
	}
	public static void main(String[] args) 
	{
		Mload m=new Mload();
		m.area(4);
		m.area(2,8);
		m.area(8.9);
	}
}

