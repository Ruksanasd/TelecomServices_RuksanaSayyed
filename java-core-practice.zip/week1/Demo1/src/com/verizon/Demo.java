package com.verizon;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method
		System.out.println("Welcome to java programming");

	}

}
