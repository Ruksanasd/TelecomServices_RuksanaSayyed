package com.verizon;

public class gettersetter {

	public static void main(String[] args) {
		

	}

}
