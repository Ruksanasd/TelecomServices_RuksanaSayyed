package com.verizon;
import java.util.Scanner;
public class switchcase {

	public static void main(String[] args) {
		
        Scanner sc=new Scanner(System.in);
		System.out.println("choose operation, 2 numbers +, -, *, /");
		char ch=sc.next().charAt(0);
		int a=sc.nextInt();
		int b=sc.nextInt();
		
		switch(ch)
		{
		case '+':System.out.println("sum="+(a+b));
		break;

		case '-':System.out.println("diff="+(a+b));
		break;
		case '*':System.out.println("product="+(a+b));
		break;
		case '/':System.out.println("quotient="+(a+b));
		break;
		}
	}
	}


