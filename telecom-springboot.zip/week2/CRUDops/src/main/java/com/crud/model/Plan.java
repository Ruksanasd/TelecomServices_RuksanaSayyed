package com.crud.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Plan {
	@Id
	Integer pid;
	@Column
	String name;
	Integer duration;
	
	Plan(){
		
	}

	public Plan(Integer pid, String name, Integer duration) {
		super();
		this.pid = pid;
		this.name = name;
		this.duration = duration;
	}

	@Override
	public String toString() {
		return "Plan1 [pid=" + pid + ", name=" + name + ", duration=" + duration + "]";
	}

	public Integer getPid() {
		return pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}
	

}
