package com.crud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crud.dao.PlanDao2;
import com.crud.model.Plan;
import com.crud.model.Plan;

import jakarta.transaction.Transactional;

@Service
//@Transactional

public class PlanService {
	@Autowired
	
	PlanDao2 plandao2;
	public String addPlan(Plan plan) {
		plandao2.save(plan);
		return "Added";
	}
	
	public List<Plan> getPlans(){
		List<Plan> plan1list=plandao2.findAll();
		return plan1list;
	}
	
	public Plan updatePlan(Integer pid,Plan plan) {
		Plan plan1=plandao2.findById(pid).get();
		plan1.setPid(plan.getPid());
		return plan1;
		}
	
	public Plan deletePlan(Integer pid) {
		Plan plan=plandao2.findById(pid).get();
		if(plan!=null)
			plandao2.deleteById(pid);
		return plan;
	}

}
