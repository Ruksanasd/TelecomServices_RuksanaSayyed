package com.crud.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.crud.model.Plan;
import com.crud.service.PlanService;

public class PlanController {
	@Autowired
	PlanService planservice;
	
	@GetMapping("/plan")
	public List<Plan> getPlanDetails() {  
		
		List<Plan> plan1=planservice.getPlans();
		return plan1;
	}

	@PostMapping("/plan") 
	public String  addCustomerDetails(@RequestBody Plan plan) {
		return planservice.addPlan(plan);
		}
	
	@PutMapping("/plan/{pid}") 
	public Plan updateCustomerDetails(@PathVariable("pid") Integer pid,@RequestBody Plan plan) {
		return planservice.updatePlan(pid, plan);
		}
	
	@DeleteMapping("/plan/{pid}") 
	public Plan deleteCustomerDetails(@PathVariable("pid") Integer pid) {
		return planservice.deletePlan(pid);
		}
	
	
}

