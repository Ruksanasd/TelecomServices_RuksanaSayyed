package com.example.CRUDops;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CruDopsApplicationTests {

	@Test
	void contextLoads() {
	}

}
